/*
Para o cálculo de vários tributos, a base de cálculo é o salário mínimo. Faça um
programa que leia o valor do salário mínimo e o valor do salário de uma pessoa. Calcule
e imprima quantos salários mínimos a pessoa ganha.
 */
package lista_lab_101;
import java.util.Scanner;
public class Exercicio_13 {
    public static void main(String[] args) {
    Scanner entrada = new Scanner (System.in);
    
    }
    
}
