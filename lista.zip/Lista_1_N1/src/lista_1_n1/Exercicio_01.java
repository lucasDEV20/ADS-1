/*
1. Escreva um programa que imprima a seguinte mensagem:
“É preciso fazer todos exercícios para aprender algoritmos!”. 
 */

package lista_1_n1;

import java.util.Scanner;

public class Exercicio_01 {

public static void main(String[] args) {
Scanner entrada = new Scanner(System.in);
    System.out.println("É preciso fazer todos exercícios para aprender algoritmos!");
    }
    
}
